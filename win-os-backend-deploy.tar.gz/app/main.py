"""Win OS backend — esqueleto (Parte 1 da sequência de execução).

Responsabilidades finais deste serviço (ainda não implementadas):
  1. Webhook da Hotmart -> cria conta + token de instalação (Parte 3)
  2. Proxy de download do pacote privado do GitHub (Parte 4)
  3. Validação de token no updater em background (Fase 2B)

Por enquanto só existe um health check, pra confirmar que o esqueleto sobe.
"""

import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.webhook.hotmart import router as hotmart_router

logger = logging.getLogger("winos")

app = FastAPI(title="Win OS Backend", version="0.1.0")
app.include_router(hotmart_router)


@app.exception_handler(RequestValidationError)
async def log_validation_errors(request: Request, exc: RequestValidationError) -> JSONResponse:
    """DEBUG TEMPORÁRIO: loga o corpo bruto quando um payload não bate com o
    schema esperado — usado só pra descobrir o formato real que a Hotmart
    manda no botão "Testar webhook" do painel. Remover depois que o schema
    do webhook estiver validado contra um payload real.
    """
    body = await request.body()
    logger.warning("422 em %s — body recebido: %s — erros: %s", request.url.path, body.decode(errors="replace"), exc.errors())
    return JSONResponse(status_code=422, content={"detail": exc.errors()})


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
